# RailOps TrainFinder Automation

This bundle contains:
- `trainfinder_fetch.py` — logs in to TrainFinder and fetches live data
- `.github/workflows/fetch.yml` — runs on a schedule and commits `trains.json`

## Setup (GitHub web on iPad)
1) Repo → **Settings → Secrets and variables → Actions**:
   - Add `TRAINFINDER_USERNAME` (your email)
   - Add `TRAINFINDER_PASSWORD` (your password)
2) Upload:
   - `trainfinder_fetch.py` at repo root
   - `.github/workflows/fetch.yml`
3) Actions tab → enable → **Run workflow**.
4) Watch for `trains.json` in repo root. If login fails, `login_debug.html` will be committed for inspection.
