# RailOps backend — GitHub-only (TF primary, PN disabled)

This backend runs entirely via GitHub Actions and commits `data/trains.json` to your repo.
Your frontend stays exactly how you have it: built from GitHub on Netlify.

## What it does

- Logs into TrainFinder using Selenium when needed (cookie in `cookie.txt`, ignored by git).
- Sweeps a dense AU grid (`scripts/viewports_au_dense.json`) to find trains.
- Parses + deduplicates to `data/trains.json`.
- PN fallback is disabled and returns no data (safe without credentials).
- Commits only when `data/trains.json` actually changes.

## Workflows

- `.github/workflows/update-trains.yml`
  - Runs every minute.
  - Two sweeps 30 seconds apart.
  - If either sweep changes `data/trains.json`, a commit is pushed.

- `.github/workflows/daily-cookie-refresh.yml`
  - Runs daily around ~04:00 Adelaide (cron `30 17 * * *` UTC).
  - Forces a login to refresh the `.ASPXAUTH` cookie.

## GitHub Action secrets to set

- `TF_EMAIL` = your TrainFinder username (e.g. `RAIL-01`)
- `TF_PASSWORD` = your TrainFinder password
- *(optional)* `PROXY_HOST`, `PROXY_PORT`, `PROXY_USER`, `PROXY_PASS` if you use ProxyMesh

## Local test

```bash
pip install -r requirements.txt
export TF_EMAIL="RAIL-01"
export TF_PASSWORD="***"

# Force login to create cookie.txt
python scripts/update_trains.py --force-login

# Then run a sweep
python scripts/update_trains.py
```

Later, if you get PN credentials again, you can wire them into `scripts/pn_fallback.py`.
