import os, json, time, hashlib, sys, pathlib
from datetime import datetime, timezone
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

from parse_tf import extract_trains_from_tf_payload, dedupe_trains
from pn_fallback import pn_fallback_if_needed

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "trains.json"

VIEWPORTS_PATH = ROOT / "scripts" / "viewports_au_dense.json"
VIEWPORTS = json.load(open(VIEWPORTS_PATH, "r", encoding="utf-8"))

TF_EMAIL = os.getenv("TF_EMAIL", "")
TF_PASSWORD = os.getenv("TF_PASSWORD", "")

PROXY_HOST = os.getenv("PROXY_HOST", "")
PROXY_PORT = os.getenv("PROXY_PORT", "")
PROXY_USER = os.getenv("PROXY_USER", "")
PROXY_PASS = os.getenv("PROXY_PASS", "")

NEXTLEVEL_URL = "https://trainfinder.otenko.com/home/nextlevel"
VIEWPORT_ENDPOINT = "https://trainfinder.otenko.com/Home/GetViewPortData"

COOKIE_PATH = ROOT / "cookie.txt"

def _session_with_cookie():
    s = requests.Session()
    if COOKIE_PATH.exists():
        txt = COOKIE_PATH.read_text(encoding="utf-8", errors="ignore").strip()
        if txt:
            s.cookies.set(".ASPXAUTH", txt, domain="trainfinder.otenko.com")
    if PROXY_HOST and PROXY_PORT and PROXY_USER and PROXY_PASS:
        proxy_str = f"http://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}"
        s.proxies.update({"http": proxy_str, "https": proxy_str})
    s.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) RailOps-Updater",
        "Accept": "application/json,text/plain,*/*",
        "Referer": "https://trainfinder.otenko.com/"
    })
    return s

def login_if_needed(force=False):
    if not force and COOKIE_PATH.exists():
        if _cookie_is_valid():
            return
    print("🔐 Logging in to TrainFinder...")
    chrome_opts = Options()
    chrome_opts.add_argument("--headless=new")
    chrome_opts.add_argument("--no-sandbox")
    chrome_opts.add_argument("--disable-dev-shm-usage")
    if PROXY_HOST and PROXY_PORT:
        chrome_opts.add_argument(f"--proxy-server=http://{PROXY_HOST}:{PROXY_PORT}")
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=chrome_opts)
    try:
        driver.get(NEXTLEVEL_URL)
        time.sleep(2)
        for sel in ["id:Email", "name:Email", "css:input[type='email']", "css:#username", "css:#Email"]:
            try:
                el = _find(driver, sel); el.clear(); el.send_keys(TF_EMAIL); break
            except Exception:
                pass
        for sel in ["id:Password", "name:Password", "css:input[type='password']", "css:#Password"]:
            try:
                el = _find(driver, sel); el.clear(); el.send_keys(TF_PASSWORD); break
            except Exception:
                pass
        for btn in ["css:button[type='submit']", "css:#loginBtn", "xpath://*[@type='submit']"]:
            try:
                _find(driver, btn).click(); break
            except Exception:
                pass
        time.sleep(5)
        asp = None
        for c in driver.get_cookies():
            if c.get("name") == ".ASPXAUTH":
                asp = c.get("value"); break
        if not asp:
            raise RuntimeError("Could not capture .ASPXAUTH cookie")
        COOKIE_PATH.write_text(asp, encoding="utf-8")
        print("✅ Cookie saved.")
    finally:
        driver.quit()

def _find(driver, sel):
    kind, val = sel.split(":", 1)
    if kind == "id":
        return driver.find_element("id", val)
    if kind == "name":
        return driver.find_element("name", val)
    if kind == "css":
        return driver.find_element("css selector", val)
    if kind == "xpath":
        return driver.find_element("xpath", val)
    raise ValueError(sel)

def _cookie_is_valid():
    try:
        s = _session_with_cookie()
        r = s.get("https://trainfinder.otenko.com/Home/IsLoggedIn", timeout=15)
        return r.status_code == 200 and ("true" in r.text.lower() or "True" in r.text)
    except Exception:
        return False

def fetch_viewport(lat, lon, zoom):
    s = _session_with_cookie()
    params = {"lat": lat, "lon": lon, "zoom": zoom}
    r = s.get(VIEWPORT_ENDPOINT, params=params, timeout=25)
    if r.status_code != 200:
        raise RuntimeError(f"Viewport fetch failed {r.status_code}")
    return r.json()

def main(force_login=False):
    login_if_needed(force=force_login)
    all_rows = []
    for vp in VIEWPORTS:
        try:
            payload = fetch_viewport(vp["lat"], vp["lon"], vp["zoom"])
            rows = extract_trains_from_tf_payload(payload)
            print(f"🟢 {vp['name']}: {len(rows)} trains")
            all_rows.extend(rows)
            time.sleep(0.5)
        except Exception as e:
            print(f"🔴 {vp['name']} error: {e}")
    all_rows = pn_fallback_if_needed(all_rows)
    all_rows = dedupe_trains(all_rows)
    out = {
        "updated_iso": datetime.now(timezone.utc).isoformat(),
        "viewport_count": len(VIEWPORTS),
        "count": len(all_rows),
        "trains": all_rows
    }
    os.makedirs(DATA_FILE.parent, exist_ok=True)
    new_blob = json.dumps(out, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    old_blob = DATA_FILE.read_text("utf-8") if DATA_FILE.exists() else ""
    if hashlib.sha256(new_blob.encode()).hexdigest() != hashlib.sha256(old_blob.encode()).hexdigest():
        DATA_FILE.write_text(new_blob, encoding="utf-8")
        print(f"💾 Wrote {DATA_FILE} with {len(all_rows)} trains.")
        return True
    else:
        print("ℹ️ No changes; skip commit.")
        return False

if __name__ == "__main__":
    force = "--force-login" in sys.argv
    changed = main(force_login=force)
    raise SystemExit(0 if changed else 2)
