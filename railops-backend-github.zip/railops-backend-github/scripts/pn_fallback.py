import time

def get_pn_rows():
    """PN fallback currently disabled (no credentials).
    Returns an empty list. You can wire this later if you get access again.
    """
    return []

def pn_fallback_if_needed(rows):
    if rows:
        return rows
    try:
        rows = get_pn_rows()
    except Exception:
        rows = []
    now = int(time.time())
    for r in rows:
        r.setdefault("updated_unix", now)
    return rows
