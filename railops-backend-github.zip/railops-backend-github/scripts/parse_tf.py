import time

def extract_trains_from_tf_payload(payload):
    out = []
    candidates = []
    if isinstance(payload, dict):
        for key in ("Trains", "trains", "Markers", "markers", "Results", "results", "Items", "items"):
            if key in payload and isinstance(payload[key], list):
                candidates = payload[key]
                break
        if not candidates and "Data" in payload and isinstance(payload["Data"], dict):
            for key in ("Trains", "trains", "Markers", "markers"):
                if key in payload["Data"] and isinstance(payload["Data"][key], list):
                    candidates = payload["Data"][key]
                    break
    elif isinstance(payload, list):
        candidates = payload

    for item in candidates:
        loco = (item.get("Loco") or item.get("LocoNumber") or item.get("Train") or
                item.get("Id") or item.get("Name") or "")
        op = item.get("Operator") or item.get("Op") or ""
        lat = item.get("Lat") or item.get("Latitude") or item.get("lat") or None
        lon = item.get("Lon") or item.get("Lng") or item.get("Longitude") or item.get("lon") or None
        hdg = item.get("Heading") or item.get("Dir") or item.get("direction") or None
        spd = item.get("Speed") or item.get("spd") or None
        svc = item.get("Service") or item.get("ServiceNo") or item.get("svc") or ""
        when = item.get("Timestamp") or item.get("Updated") or item.get("when") or int(time.time())

        if lat is None or lon is None:
            continue

        out.append({
            "loco": str(loco),
            "operator": str(op),
            "service": str(svc),
            "lat": float(lat),
            "lon": float(lon),
            "heading": hdg if hdg is None else float(hdg),
            "speed_kmh": spd if spd is None else float(spd),
            "updated_unix": when if isinstance(when, int) else int(time.time())
        })
    return out


def dedupe_trains(rows):
    best = {}
    for r in rows:
        key = r["loco"].strip().upper() if r["loco"] else f"{r['lat']:.5f},{r['lon']:.5f}:{r['operator']}"
        curr = best.get(key)
        if (curr is None) or (r.get("updated_unix", 0) > curr.get("updated_unix", 0)):
            best[key] = r
    return list(best.values())
